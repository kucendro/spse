package sprava_uzivatelu;

public class TUI {
    public void start() {

        // !------------------------------ HELLO message
        // Sorry for the colors haha i am gay actually XD
        System.out.println(
                "\n" + "------ " + "\u001B[31m" + "H" + "\u001B[33m" + "E" + "\u001B[33m" + "L" + "\u001B[32m" + "L"
                        + "\u001B[34m" + "O" + "\u001B[0m" + " ------" + "\n");
        // !------------------------------

        System.out.println("Choose an option!");
        System.out.println("1 - Sign up");
        System.out.println("2 - Sign in");
        System.out.println("3 - Administration");
        String choice = System.console().readLine();

        switch (choice) {
            case "1":
                System.out.println("Enter username:");
                String username = System.console().readLine();
                System.out.println("Enter password:");
                char[] password = System.console().readPassword();

                StoreCredentials.hash(username, password);
                break;

            case "2":
                System.out.println("Try to log in...");
                System.out.println("Enter username:");
                String logUserName = System.console().readLine();
                System.out.println("Enter password:");
                char[] logPassword = System.console().readPassword();

                if (VerifyCredentials.verify(logUserName, logPassword) != null) {
                    System.out.println("Welcome, " + logUserName + "!");
                } else {
                    System.out.println("\u001B[31m" + "Access denied." + "\u001B[0m");
                }
                break;

            case "3":
                // TODO: Administration

            default:
                System.out.println("\u001B[31m" + "Invalid option." + "\u001B[0m");
                break;
        }
    }
}
